"""
Branca plugins
--------------

Add different objects/effects in a branca webpage.
"""

__all__ = []
