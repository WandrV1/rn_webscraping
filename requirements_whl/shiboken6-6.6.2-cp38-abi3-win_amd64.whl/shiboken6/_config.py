shiboken_library_soversion = str(6.6)

version = "6.6.2"
version_info = (6, 6, 2, "", "")

__build_date__ = '2024-02-12T07:18:47+00:00'




__setup_py_package_version__ = '6.6.2'

